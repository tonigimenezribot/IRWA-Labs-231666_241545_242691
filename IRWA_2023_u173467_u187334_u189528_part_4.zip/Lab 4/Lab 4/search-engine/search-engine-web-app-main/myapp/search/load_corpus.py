import pandas as pd
import nltk
from collections import defaultdict
from array import array
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords
import math
import numpy as np
import collections
from numpy import linalg as la
import time
import json
import re
import pandas as pd
from sklearn.manifold import TSNE
from numpy.linalg import norm
from myapp.core.utils import load_json_file
from myapp.search.objects import Document

_corpus = {}

# BUILD TERMS
def build_terms(line):
    stemmer = PorterStemmer()
    stop_words = set(stopwords.words("english"))

    # Tweet Text and Tweet date to lowercase and tokenized
    line['Tweet Text'] =  line['Tweet Text'].lower().split()
    #line['Tweet Date']=  line['Tweet Date'].lower().split()

    # HASHTAGS
    # To lowercase
    line['Hashtags'] = [word.lower() for word in line['Hashtags']]

    line['Tweet Text'] = [word for word in line['Tweet Text'] if word[0] != '#']

    #EXTRA-- DELETE SYMBOLS
    # Decided to delete the hashtags symbols as we have the list of hashtags in the dictionary
    line['Tweet Text'] = [re.sub(r"[^\w\s']+", '', word) for word in line['Tweet Text']]

    # DELETE PUNCTUATION
    # EXTRA IF word is a link NOT TO DELETE THE punctuation SYMBOLS
    line['Tweet Text'] = [re.sub(r"[,.;@#?!&$]+", '', word) for word in line['Tweet Text'] if not word.startswith('https')]

    # EXTRA-- DELETE EMPTY STRINGS ""
    line['Tweet Text']= [word for word in line['Tweet Text'] if word != '']

    #DELETE STOPWORDS
    line['Tweet Text']= [word for word in line['Tweet Text'] if word not in stop_words]

    # DEALING WITH STEMMING
    line['Tweet Text']= [stemmer.stem(word) for word in line['Tweet Text']]


    return line

def load_corpus(path) -> [Document]:
    """
    Load file and transform to dictionary with each document as an object for easier treatment when needed for displaying
     in results, stats, etc.
    :param path:
    :return:
    """
    with open(path) as fp:
        # Read the file
        lines = fp.readlines()
        

    data = []
    for i in lines:
        data.append(json.loads(i))
    # STRUCTURE

    # docID | Tweet | ID | Date | Hashtags | Likes | Retweets | Url
    # Create a list of dictionaries
    tweet_dicts = []

    for i in range(len(data)):
        doc_id = 'doc_' + str(i+1)
        tweet_text = data[i]['full_text']
        tweet_id = data[i]['id']
        tweet_date = int(data[i]['created_at'][28:30])
        hashtags = [hashtag['text'] for hashtag in data[i]['entities']['hashtags']]
        likes = data[i]['favorite_count']
        retweets = data[i]['retweet_count']
        url = 'https://twitter.com/' + str(data[i]['user']['screen_name'])+'/status/'+str(tweet_id)

        # Create a dictionary for each tweet
        tweet_dict = {'DOC_ID': doc_id, 'Tweet Text': tweet_text, 'Tweet ID': tweet_id, 'Tweet Date': tweet_date, 'Hashtags': hashtags,
                    'Likes': likes, 'Retweets': retweets, 'URL': url}
        tweet_dicts.append(tweet_dict)
        
    for tweet in tweet_dicts:
        tweet = build_terms(tweet)        
    # Create Document object
    for tweet in tweet_dicts:
        document = Document(tweet['DOC_ID'], tweet['Tweet Text'], tweet['Tweet ID'], tweet['Tweet Date'],
                            tweet['Likes'], tweet['Hashtags'], tweet['Retweets'], tweet['URL'])
        _corpus[tweet['DOC_ID']] = document

    return _corpus




#  BUILD QUERY TERMS
def build_terms_query(query):
    # To lowercase and tokenized
    query = query.lower().split()
    stemmer = PorterStemmer()
    stop_words = set(stopwords.words("english"))
    #DELETE STOPWORDS
    query = [word for word in query if word not in stop_words]
    # DEALING WITH STEMMING
    query = [stemmer.stem(word) for word in query]
    return query

'''
def _load_corpus_as_dataframe(path):
    """
    Load documents corpus from file in 'path'
    :return:
    """
    json_data = load_json_file(path)

    tweets_df = _load_tweets_as_dataframe(json_data)
    _clean_hashtags_and_urls(tweets_df)
    # Rename columns to obtain: Tweet | Username | Date | Hashtags | Likes | Retweets | Url | Language
    corpus = tweets_df.rename(
        columns={"id": "Id", "full_text": "Tweet", "screen_name": "Username", "created_at": "Date",
                 "favorite_count": "Likes",
                 "retweet_count": "Retweets", "lang": "Language"})

    # select only interesting columns
    filter_columns = ["Id", "Tweet", "Username", "Date", "Hashtags", "Likes", "Retweets", "Url", "Language"]
    corpus = corpus[filter_columns]
    return corpus


def _load_tweets_as_dataframe(json_data):
    data = pd.DataFrame(json_data).transpose()
    # parse entities as new columns
    data = pd.concat([data.drop(['entities'], axis=1), data['entities'].apply(pd.Series)], axis=1)
    # parse user data as new columns and rename some columns to prevent duplicate column names
    data = pd.concat([data.drop(['user'], axis=1), data['user'].apply(pd.Series).rename(
        columns={"created_at": "user_created_at", "id": "user_id", "id_str": "user_id_str", "lang": "user_lang"})],
                     axis=1)
    return data


def _build_tags(row):
    tags = []
    # for ht in row["hashtags"]:
    #     tags.append(ht["text"])
    for ht in row:
        tags.append(ht["text"])
    return tags


def _build_url(row):
    url = ""
    try:
        url = row["entities"]["url"]["urls"][0]["url"]  # tweet URL
    except:
        try:
            url = row["retweeted_status"]["extended_tweet"]["entities"]["media"][0]["url"]  # Retweeted
        except:
            url = ""
    return url


def _clean_hashtags_and_urls(df):
    df["Hashtags"] = df["hashtags"].apply(_build_tags)
    df["Url"] = df.apply(lambda row: _build_url(row), axis=1)
    # df["Url"] = "TODO: get url from json"
    df.drop(columns=["entities"], axis=1, inplace=True)


def load_tweets_as_dataframe2(json_data):
    """Load json into a dataframe

    Parameters:
    path (string): the file path

    Returns:
    DataFrame: a Panda DataFrame containing the tweet content in columns
    """
    # Load the JSON as a Dictionary
    tweets_dictionary = json_data.items()
    # Load the Dictionary into a DataFrame.
    dataframe = pd.DataFrame(tweets_dictionary)
    # remove first column that just has indices as strings: '0', '1', etc.
    dataframe.drop(dataframe.columns[0], axis=1, inplace=True)
    return dataframe


def load_tweets_as_dataframe3(json_data):
    """Load json data into a dataframe

    Parameters:
    json_data (string): the json object

    Returns:
    DataFrame: a Panda DataFrame containing the tweet content in columns
    """

    # Load the JSON object into a DataFrame.
    dataframe = pd.DataFrame(json_data).transpose()

    # select only interesting columns
    filter_columns = ["id", "full_text", "created_at", "entities", "retweet_count", "favorite_count", "lang"]
    dataframe = dataframe[filter_columns]
    return dataframe


def _row_to_doc_dict(row: pd.Series):
    _corpus[row['Id']] = Document(row['Id'], row['Tweet'][0:100], row['Tweet'], row['Date'], row['Likes'],
                                  row['Retweets'],
                                  row['Url'], row['Hashtags'])
'''


