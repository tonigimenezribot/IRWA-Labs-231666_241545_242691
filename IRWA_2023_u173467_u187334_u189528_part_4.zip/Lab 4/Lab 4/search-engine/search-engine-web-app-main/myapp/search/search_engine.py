import random

from myapp.search.objects import ResultItem, Document
import myapp.search.algorithms as algorithms
import myapp.search.load_corpus as load_corpus


def build_demo_results(corpus: dict, search_id, search_results):
    """
    Helper method to create a list of ResultItems from ranked search results
    :return: a list of ResultItems sorted by ranking
    """
    res = []
    i = 0 
    for doc_id in search_results:
        item = corpus[doc_id]  # Assuming corpus is a dictionary of Document instances
        res.append(ResultItem(
            doc_id=item.doc_id,
            tweet_text=item.tweet_text,
            tweet_id=item.tweet_id,
            tweet_date=item.tweet_date,
            likes=item.likes,
            hashtags=item.hashtags,
            retweets=item.retweets,
            url=item.url, ranking = i
        ))
        i = i+ 1
        # "doc_details?id={}&search_id={}&param2=2".format(item.doc_id, search_id)
    return res


class SearchEngine:
    """educational search engine"""

    def search(self, search_query, search_id, corpus):
        print("Search query:", search_query)
        
        ##### your code here #####
        # call to search algorithm
        index = algorithms.create_index(corpus)

        results = algorithms.search_tf_idf(search_query, corpus, index)
        ##### your code here #####
        results = build_demo_results(corpus, search_id, results)
        
        return results
    
