import nltk
from collections import defaultdict
from array import array
import math
import numpy as np
import collections
from numpy import linalg as la
from numpy.linalg import norm
from myapp.search.load_corpus import build_terms_query
# CREATE THE INDEX
def create_index(corpus):
    index = defaultdict(list)

    for doc_id, doc in corpus.items():
        tweet_text = doc.tweet_text  # Assuming 'tweet_text' is a list of terms in a Document
        for term in tweet_text:
            
            if doc_id not in index[term]:
                index[term].append(doc_id)
                

    return index

def search_tf_idf(query, corpus, index):
    query = build_terms_query(query)
    docs = None
    for term in query:
        try:
            
            term_docs = set(index[term])
            #print(term, len(term_docs))
            if docs is None:
                docs = term_docs
            else:
                docs = docs.intersection(term_docs)

        except KeyError:
            # Term is not in index
            pass
    docs = list(docs)
    print(docs)
    ranked_docs = search_in_corpus(query, docs, corpus)
    return ranked_docs


def search_in_corpus(query, docs, corpus):
    # 1. create create_tfidf_index
    lines = corpus
    index = create_index(lines)
    tf = defaultdict(list)
    df = defaultdict(int)
    idf = defaultdict(float)

    # Computing N total # of documents
    N = len(lines)

    # for each document
    for doc_id, doc in corpus.items():

        # the build terms in the tweet
        terms = doc.tweet_text
        T_count = defaultdict(int)

        # how many terms in the tweet T
        for term in terms:
            T_count[term] += 1

        # Normalize term frequencies in the document !D!
        norm = math.sqrt(sum(count ** 2 for count in T_count.values()))

        # TF d,t = N t, d / !D!
        for term, count in T_count.items():
            tf_value = np.round(((1+np.log(count))/norm), 4)
            tf[term].append(tf_value)
            # df = # of documents where term occurs
            df[term] += 1

    # IDF t = log( N / df t)
    for term in df:
        idf[term] = np.round(np.log(float(N / df[term])),4)
    
    ###########################################################
    # 2. apply ranking
    doc_vectors = defaultdict(lambda: [0] * len(terms))
    query_vector = [0] * len(terms)

    query_terms_count = collections.Counter(terms)

    query_norm = np.linalg.norm(list(query_terms_count.values()))

    # Calculate query vector
    for termIndex, term in enumerate(terms):
        if term not in index:
            continue
        query_vector[termIndex] = (1 + np.log(query_terms_count[term]))/query_norm * idf[term]

        for doc_index, doc in enumerate(index[term]):
            if doc in docs:
                doc_vectors[doc][termIndex] = tf[term][doc_index] * idf[term]

    # Calculate cosine similarity
    doc_scores = [[np.dot(curDocVec, query_vector) / (np.linalg.norm(curDocVec) * np.linalg.norm(query_vector)), doc_1] for doc_1, curDocVec in doc_vectors.items()]
    doc_scores.sort(reverse=True)

    for score, doc_id in doc_scores:
        print(f"Document ID: {doc_id}, Cosine Similarity: {score}")

    result_docs = [x[1] for x in doc_scores]
    
    return result_docs


