import json


class Document:
    """
    Original corpus data as an object
    """

    def __init__(self, doc_id, tweet_text, tweet_id, tweet_date, likes, hashtags, retweets, url):
        self.doc_id = doc_id
        self.tweet_text = tweet_text
        self.tweet_id = tweet_id
        self.tweet_date = tweet_date
        self.likes = likes
        self.hashtags = hashtags
        self.retweets = retweets
        self.url = url

    def to_json(self):
        return self.__dict__

    def __str__(self):
        """
        Print the object content as a JSON string
        """
        return json.dumps(self)
    
class ResultItem:
    def __init__(self, doc_id, tweet_text, tweet_id, tweet_date, likes, hashtags, retweets, url, ranking):
        self.doc_id = doc_id
        self.tweet_text = tweet_text
        self.tweet_id = tweet_id
        self.tweet_date = tweet_date
        self.likes = likes
        self.hashtags = hashtags
        self.retweets = retweets
        self.url = url
        self.ranking = ranking

class StatsDocument:
    """
    Original corpus data as an object
    """

    def __init__(self, doc_id, tweet_text, tweet_id, tweet_date, likes, hashtags, retweets, url, count):
        self.doc_id = doc_id
        self.tweet_text = tweet_text
        self.tweet_id = tweet_id
        self.tweet_date = tweet_date
        self.likes = likes
        self.hashtags = hashtags
        self.retweets = retweets
        self.url = url
        self.count = count

    def __str__(self):
        """
        Print the object content as a JSON string
        """
        return json.dumps(self)


